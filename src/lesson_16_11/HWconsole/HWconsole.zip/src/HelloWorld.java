/**
*@author RBykova
*/

public class HelloWorld{

	public static final String HELLO_MESSAGE = "Hello, World!";
	/**
	*@param args command prompt parameters
	*/
	public static void main(String [] args){
	System.out.println(HELLO_MESSAGE);
	}
	
}